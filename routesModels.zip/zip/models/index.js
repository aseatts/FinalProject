module.exports = {
  profiletypes: require("./profileType")
  // ,ProfileQuestion: require("./profileQuestion")
  // ,ProfileName: require("./profileName")
};
// module.exports = { ProfileType  = require("./profileType")};
// module.exports = { ProfileQuestion  = require("./profileQuestion")};
// module.exports = { ProfileName  = require("./profileName")};

// module.exports = { ProfileType  = require("./profileType")};
// module.exports = { ProfileQuestion  = require("./profileQuestion")};
// module.exports = { ProfileName  = require("./profileName")};

// module.exports = { ProfileUser } = require("./User");
